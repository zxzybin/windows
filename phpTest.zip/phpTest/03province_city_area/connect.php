<?php
header("Content-type:text/html;charset=utf-8");
$host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "mydb";
$timezone = "Asia/Shanghai";
$connect = @mysqli_connect($host,$db_user,$db_pass,$db_name);
if(@mysqli_connect_error($connect)){
    echo "数据库连接失败".mysqli_connect_error($connect);
}
@mysqli_query($connect,"SET names UTF8");

@date_default_timezone_set($timezone);


