<?php
require ('connect.php');

//@mysqli_query($connect,"insert into comment values (7,110000,'北京市','images/g10.png',0) ");


$code = $_GET['cityCode'];
//$callback = $_GET['callback'];
$flag = $_GET['flag'];

if($flag == 1){
    $query = @mysqli_query($connect,"select *from t_address_province order by id");
}
if($flag == 2){
    $query = @mysqli_query($connect,"select *from t_address_city where provinceCode = '".$code."' order by id");
}

if($flag == 3){
    $query = @mysqli_query($connect,"select *from t_address_town where cityCode = '".$code."' order by id");
}
$saylist = [];
while ($row = @mysqli_fetch_array($query)){
    $saylist[] = array(
        'code' => $row['code'],
        'name' => $row['name']
    );
}

if($saylist){
//    echo $callback . "(" .json_encode($saylist). ")";
    echo json_encode($saylist);
}else{
    echo json_encode();
}