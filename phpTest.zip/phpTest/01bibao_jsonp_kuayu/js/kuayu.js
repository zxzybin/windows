/**
 * Created by Zhangleibin on 2017/8/21.
 */
hello({username:"zhangsan",password:"123456"});