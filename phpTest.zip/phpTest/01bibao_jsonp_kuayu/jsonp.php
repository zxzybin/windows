<?php
$jsonp = $_GET['_jsonp'];

$arr = array("zhaoda","qianer","sunsan","lisi");

echo $jsonp . "(" .json_encode($arr) . ")";
