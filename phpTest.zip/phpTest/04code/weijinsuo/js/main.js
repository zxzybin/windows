/**
 * Created by Zhangleibin on 2017/8/23.
 */
$(function () {

    function resize() {
        var windowWidth = $(window).width();

        var isSmallScreen = windowWidth < 768;

        $('#main_ad > .carousel-inner > .item').each(function (i,item) {
            var $item = $(item); //dom对象转换为jq对象
            var imgSrc = $item.data(isSmallScreen ? 'image-xs' : 'image-lg');
            $item.css('backgroundImage','url("'+imgSrc+'")');

            if(isSmallScreen){
               $item.html('<img src="'+imgSrc+'"/>');
            }else{
                $item.empty();
            }
        });
    }

    $(window).on('resize',resize).trigger('resize');

    //初始化tooltips插件
    $('[data-toggle="tooltip"]').tooltip();
    
    
    /*控制标签页的标签宽度*/
    var $ulContainer = $('.nav-tabs');
    var width = 30; //原来的ul上有padding-left
    $ulContainer.children().each(function (index,element) {
        width += element.clientWidth;
        // console.log($(element).width());
    });

    //判断当前ul是否超出了屏幕,超出就显示横向滚动条
    if(width > $(window).width()){
        $ulContainer.css('width',width).parent().css('overflow-x','scroll');
    }

    //a点击注册事件
    var $newTitle = $('.news-title');
    $('#news .nav-pills a').on('click',function () {
        var $this = $(this);
        var title = $this.data('title');
        $newTitle.text(title);
    });

    //获取界面上的轮播图组件
    var $carousel = $('.carousel');
    var startX,endX;
    var offset = 50;
    //注册滑动事件
    $carousel.on('touchstart',function (e) {

        startX = e.originalEvent.touches[0].clientX;
        console.log(startX);

    });

    $carousel.on('touchmove',function (e) {
        //重复赋值,取到最后一个值
        endX = e.originalEvent.touches[0].clientX;
        console.log(endX);
    })

    $carousel.on('touchend',function (e) {
    // startX = e.originalEvent.touches[0].clientX;
    // console.log(startX > endX ? "向左":"向右");

        //控制精度 获取每次运动的距离,当距离大于一定值时,认为是有方向变化
        var distance = Math.abs(startX-endX);
            if(distance > offset){
                //有方向变化
                //获取手指在轮播图元素上的一个滑动方向(左右)
                //根据或得到的方向选择上一张还是下一张
                //原生的carousel方法实现
                $(this).carousel(startX > endX ? 'next':'prev');
            }

    });







});