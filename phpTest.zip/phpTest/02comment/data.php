<?php
require ('connect.php');

$last = $_GET['last'];
$amount = $_GET['amount'];

$query = @mysqli_query($connect,"select *from comment order by id limit $last,$amount");
$flag = false;

while ($row = @mysqli_fetch_array($query)){


    $flag = true;
    $sayList[] = array(
        'id' => $row['id'],
        'nickname' => $row['nickname'],
        'content' => $row['content'],
        'imgpath' => $row['imgpath'],
        'time'=> $row['time']
    );
};
if($flag){
    echo json_encode($sayList);
}else{
    echo true;
}


@mysqli_close($connect);