<?php
header("Content-type:text/html;charset=utf-8");
$host = "localhost";
$db_user = "root";
$db_password = "";
$db_name = "mydb";
$timezone = "Asia/Shanghai";

$connect = @mysqli_connect($host,$db_user,$db_password,$db_name);
if(@mysqli_connect_error($connect)){
    echo "连接MYSQL失败: ".@mysqli_connect_error();
}

@mysqli_query($connect,"SET names UTF8");

date_default_timezone_set($timezone);
