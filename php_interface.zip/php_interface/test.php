<?php
//require_once('./json_xml_interface.php');
//$arr = array(
//    'id'=>1,
//    'name'=>'singwa',
//);
//Response::json(200,'数据返回成功');
//Response::xml();
//$data = array(
//    'id'=>2,
//    'name'=>'singwa02',
//);
//Response::show(200,'success',$data,'json');
//Response::show(200,'success',$data,'xml');
//Response::show(200,'success',$data,'array');



/***********写入文件*****读取缓存******删除缓存********/
require_once('./file.php');
$data = array(
    'id'=>1,
    'name'=>'singma',
    'type'=>array(4,5,6),
    'test'=>array(1,45,67=>array(123,'ashdkjhask'),),
);
$file = new File();

if($file->cacheData('index_muke_cache',$data)){
//var_dump($file->cacheData('index_muke_cache'));exit;
    echo 'success';
}else{
    echo 'error';
};
