<?php
class Db{

    static private $_instance;
    static private $_connectSource;
    private $_dbConfig = array(

        'host' => 'localhost',
        'user' => 'root',
        'password' => '',
        'database' => 'video',

    );
    private function __construct(){

    }

    static function getInstance(){

        if(!(self::$_instance instanceof self)){    //判断是否存在这个对象,保证唯一性
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function connect(){

        if(!self::$_connectSource){

            self::$_connectSource = @mysql_connect($this->_dbConfig['host'],$this->_dbConfig['user'],
                $this->_dbConfig['password'],
                $this->_dbConfig['database']);
            if(!self::$_connectSource){

                throw new Exception('mysql connect error'.@mysql_error());

                //die('mysql connect error'.@mysql_error());
            }

            @mysql_select_db($this->_dbConfig['database'],self::$_connectSource);
            @mysql_query('set names UTF8',self::$_connectSource);
        }

       return self::$_connectSource;

    }


}

//$db = new Db();   //此处为私有的构造函数

//$connect = Db::getInstance()->connect(); //连接数据库操作
//$sql = "select *from admin";
//$result = @mysql_query($sql,$connect);
//echo @mysql_num_rows($result);
//var_dump($result);

