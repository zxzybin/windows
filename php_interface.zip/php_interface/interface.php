<?php
/*
 *  定义一个接口
 *  提供一个标准
 *  接口中的定义的方法都要实现,否则会在实现的地方报错
 * */

//声明
interface video{

    public function getVideos();
    public function getCounts();

}
//实现
class movie implements video{

    public function getVideos()
    {
        echo 1;
    }

    public function getCounts()
    {
        echo 2;
    }
}
//调用
//movie::getVideos();

