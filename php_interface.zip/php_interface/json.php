<?php
/*
 * php生成json数据
 * 方法:json_endecode($value)
 * 注:该函数只接受UTF-8编码的数据,如果传递其他格式的数据该函数会返回null
 *
 *
 *
 * */
$arr = array(
    'name' => '张雷宾',
    'sex' =>  '男',
    'englishname'=>'lambert',
    'height'=>'175',
    'address'=>'henanzhengzhou',
    'description'=>'我只是一名小开发仔而已',
);
echo json_encode($arr);

function json($arr){
    echo json_encode($arr);
    exit;

}
