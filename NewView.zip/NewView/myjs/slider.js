/**
 * Created by Zhangleibin on 2017/5/9.
 */
$(function () {

    $('.slider-ctrl-prev,.slider-ctrl-next').hide();
    var js_slider = $('#js_slider');
    var js_slider_main_block = $('#slider_main_block');
    var imgs = js_slider_main_block.children();
    var slider_ctrl = $('#slider_ctrl');

    for(var i = 0; i <imgs.length; i++){
        var span = $('<span></span>');
        span.addClass('slider-ctrl-con');
        span.html(i+1);

        slider_ctrl.children('span:last-child').before(span);
    }
    var spans = slider_ctrl.children();
    spans.eq(1).addClass('current');

    var scrollWidth = js_slider[0].clientWidth;
    for (var i = 1; i <imgs.length;i++){
        imgs[i].style.left = scrollWidth + 'px';
    }

    var iNow = 0;
    for(var k in spans){
        spans.eq(k).click(function () {
            if($(this).is('.slider-ctrl-prev')){
                imgs.eq(iNow).animate({left:scrollWidth},500);
                --iNow < 0 ? iNow = imgs.length - 1 :iNow;
                imgs[iNow].style.left = -scrollWidth + 'px';
                imgs.eq(iNow).animate({left:0},500);
                setSquare();
            }
            else if($(this).is('.slider-ctrl-next')){
                autoplay();
            }
            else {
                var that = $(this).html()-1;
               if(that > iNow){
                   imgs.eq(iNow).animate({left:-scrollWidth},500);
                   imgs[that].style.left = scrollWidth + 'px';


               }
               else if(that < iNow){
                   imgs.eq(iNow).animate({left:scrollWidth},500);
                   imgs[that].style.left = -scrollWidth + 'px';

               }
               iNow = that;
                imgs.eq(that).animate({left:0},500);
                setSquare();
            }
        });

    }

    function setSquare() {
        for(var i = 1; i < spans.length - 1; i++){
            spans[i].className = 'slider-ctrl-con';
        }
        spans[iNow + 1].className = 'slider-ctrl-con current';
    }


    var timer = null;
    timer = setInterval(autoplay,2000);
    function autoplay() {
        imgs.eq(iNow).animate({left:-scrollWidth},500);
        ++iNow > imgs.length - 1 ? iNow = 0 : iNow;
        imgs[iNow].style.left = scrollWidth + 'px';
        imgs.eq(iNow).animate({left:0},500);
        setSquare();
    }

    js_slider.hover(function () {
        clearInterval(timer);
        $('.slider-ctrl-prev,.slider-ctrl-next').show();
    },function () {
        clearInterval(timer);
        timer = setInterval(autoplay,2000);
        $('.slider-ctrl-prev,.slider-ctrl-next').hide();
    });

})