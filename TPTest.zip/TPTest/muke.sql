/*
Navicat MySQL Data Transfer

Source Server         : 本地
Source Server Version : 50617
Source Host           : localhost:3306
Source Database       : muke

Target Server Type    : MYSQL
Target Server Version : 50617
File Encoding         : 65001

Date: 2017-04-07 10:03:24
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for mk_user
-- ----------------------------
DROP TABLE IF EXISTS `mk_user`;
CREATE TABLE `mk_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `nick_name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `score` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of mk_user
-- ----------------------------
INSERT INTO `mk_user` VALUES ('3', 'kitty', '试试', '123456', '100', '2017-04-28 20:31:52', '2017-04-05 16:24:02');
INSERT INTO `mk_user` VALUES ('4', '小红', '红红', 'e10adc3949ba59abbe56e057f20f883e', '60', '2017-04-05 16:28:20', '2017-04-05 16:28:20');
INSERT INTO `mk_user` VALUES ('21', '小红1', '红红1', 'e10adc3949ba59abbe56e057f20f883e', '96', '2017-04-05 16:47:10', '2017-04-05 16:47:10');
INSERT INTO `mk_user` VALUES ('22', '小红2', '红红2', 'e10adc3949ba59abbe56e057f20f883e', '97', '2017-04-05 16:47:10', '2017-04-05 16:47:10');
INSERT INTO `mk_user` VALUES ('23', '小红3', '红红3', 'e10adc3949ba59abbe56e057f20f883e', '98', '2017-04-05 16:47:10', '2017-04-05 16:47:10');
INSERT INTO `mk_user` VALUES ('42', '小李', '红红4', '12346', '100', '2017-04-06 16:55:57', '2017-04-06 16:56:01');

-- ----------------------------
-- Table structure for mk_user2
-- ----------------------------
DROP TABLE IF EXISTS `mk_user2`;
CREATE TABLE `mk_user2` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `nick_name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `score` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of mk_user2
-- ----------------------------
INSERT INTO `mk_user2` VALUES ('1', 'xiaohonga', 'honghonga', '102', '123456', '2017-04-06 18:03:41', '2017-04-06 18:03:44');
INSERT INTO `mk_user2` VALUES ('2', 'xiaohongb', 'honghongb', '101', '123456', '2017-04-06 18:04:34', '2017-04-06 18:04:31');
INSERT INTO `mk_user2` VALUES ('3', 'xiaohongc', 'honghongc', '103', '123456', '2017-04-06 18:04:58', '2017-04-06 18:05:02');

-- ----------------------------
-- Table structure for mk_userinfo
-- ----------------------------
DROP TABLE IF EXISTS `mk_userinfo`;
CREATE TABLE `mk_userinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `real_name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `address` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of mk_userinfo
-- ----------------------------
INSERT INTO `mk_userinfo` VALUES ('1', '3', 'kitty0', '香港');
INSERT INTO `mk_userinfo` VALUES ('2', '4', '小红0', '香港');
INSERT INTO `mk_userinfo` VALUES ('3', '21', '小红10', '台湾');
INSERT INTO `mk_userinfo` VALUES ('4', '22', '小红20', '上海');
INSERT INTO `mk_userinfo` VALUES ('5', '23', '小红30', '厦门');
INSERT INTO `mk_userinfo` VALUES ('6', '42', '小红40', '福州');
