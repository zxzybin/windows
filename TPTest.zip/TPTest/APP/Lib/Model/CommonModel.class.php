<?php
/**
 * Created by PhpStorm.
 * User: Zhangleibin
 * Date: 2017/4/1
 * Time: 16:36
 */
class CommonModel extends Model{

    public  function strmake($str){

        return  md5(sha1(md5($str)));



    }
}