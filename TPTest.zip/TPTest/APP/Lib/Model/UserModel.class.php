<?php
/**
 * Created by PhpStorm.
 * User: Zhangleibin
 * Date: 2017/4/1
 * Time: 15:56
 */
class UserModel extends Model{
//    public function getInfo(){
        //用户业务逻辑处理


        protected $_scope=array(
            /*'命名范围的标示名'=>array(
             '属性'=>'值',
            支持的方法有:where limit field order table having group disinct
            )
            */
            'jide'=>array(
                'where'=>array(
                    'score'=>array('egt',60),
                ),
                'order'=>'id asc',
                'limit'=>10
            ),
            'ziduan'=>array(
                'field'=>'nick_name,score',
                'limit'=>5
            )
        );

//        return 'hello world';
//    }

}