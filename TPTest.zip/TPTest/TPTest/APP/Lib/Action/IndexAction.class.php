<?php
// 本类由系统自动生成，仅供测试用途
class IndexAction extends Action {
    public function fanwei(){
        $user=D('User');
        $data=$user->scope('jide,ziduan')->where('id<50')->select();
        echo M()->getLastSql();
    }

    public function index(){

//	$this->show('<style type="text/css">*{ padding: 0; margin: 0; } div{ padding: 4px 48px;} body{ background: #fff; font-family: "微软雅黑"; color: #333;} h1{ font-size: 100px; font-weight: normal; margin-bottom: 12px; } p{ line-height: 1.8em; font-size: 36px }</style><div style="padding: 24px 48px;"> <h1>:)</h1><p>欢迎使用 <b>ThinkPHP</b>！</p></div><script type="text/javascript" src="http://tajs.qq.com/stats?sId=9347272" charset="UTF-8"></script>','utf-8');
//     echo C('name');
//     show();


//        $this->display('test');  //调用test.html

//    	echo C('name');
//    	echo C('sex');


        //URL_MODEL
        /*
         * 1.默认模式 pathinfo
         * 0.普通模式
         * 2.重写模式
         * 3.兼容模式
         * */


//        show();
//        $arr = array(1,2,3,4,5);
//        dump($arr);
//        $this->display(); //输出模板文件下的index文件
//        $this->display('test'); //输出模板文件下的test文件


//        $name = 'Dosen';
//        $this->name2=$name; //变量取别名
//        $this->assign('变量名','变量值');
//        $date=date('Y-m-d');
//        $this->date=$date;
//        $this->assign('name',$name);
//        $this->display();


//        $me['name']='张三';
//        $me['sex']='男';
//        $this->assign('me',$me);
//        $this->display();


//
//        for($i=0;i<$person.count;$i++){
//            echo i;
//        }


//        $this->assign('person',$person);
//        $this->display();


//        $num=13;
//        $this->assign('num',$num);
//        $this->display();


//        $name='xiaoming';
//        $this->assign('name',$name);


        //标签小实战
        /*
        $person=array(
            1=>array('name'=>'Jack','age'=>'18'),
            2=>array('name'=>'Tom','age'=>'19'),
            3=>array('name'=>'Peter','age'=>'17'),
            4=>array('name'=>'Mary','age'=>'21'),
        );
        $this->assign('person',$person);
        $this->display();
        */

//        echo C('sex');

    }

    public function user(){
//        echo C('name'); //创建user.html,调用
//        trace('name',C('name'));
//        dump($_SESSION);
//        dump($_SERVER);

/*        $count='';
        G('run');
        for ($i=0;$i<1000000;$i++){
            $count+= $i;
        }
      echo  G('run','end');

        $this->display(); //调用user模板
*/

        //1.实例化基础模型model
//        $user = new Model('user'); //表名 表前缀 数据库连接信息
//        $user = M('user');
//        $data = $user->select();
//        dump($data);

        //2.实例化用户自定义模型
//            $user = new UserModel();
//            $user = D('User');  //D方法比M方法更强大
//            echo $user->getInfo();

        //3.实例化公共模型
//        $user = new CommonModel();
//        echo  $user->strmake('aaaaa');
//        $user = D('Common');
//        echo $user->strmake('bbbbbb');

        //4.实例化空模型
//        $model = M();
//        $sql='select *from mk_user';
//        $data = $model->query($sql); //读取 select
//写入 update insert
//        dump($data);
//        $data =  $model->execute('update mk_user set user_name="kitty" where id=3;');



//************数据库CURD操作*********

//add 创建单条数据
/* 单条插入
    $data = array(
        'user_name'=>'小红',
        'nick_name'=>'红红',
        'password'=>md5('123456'),
        'score'=>'98',
        'create_date'=>date('Y-m-d H:i:s'),
        'update_date'=>date('Y-m-d H:i:s'),
    );
    echo  M('User')->add($data); //实例化user表,并添加单条数据
*/

/*多条插入
    $data = array(
        0=>array(
            'user_name'=>'小红1',
            'nick_name'=>'红红1',
            'password'=>md5('123456'),
            'score'=>'98',
            'create_date'=>date('Y-m-d H:i:s'),
            'update_date'=>date('Y-m-d H:i:s'),
        ),
        1=>array(
            'user_name'=>'小红2',
            'nick_name'=>'红红2',
            'password'=>md5('123456'),
            'score'=>'98',
            'create_date'=>date('Y-m-d H:i:s'),
            'update_date'=>date('Y-m-d H:i:s'),
        ),
        2=>array(
            'user_name'=>'小红3',
            'nick_name'=>'红红3',
            'password'=>md5('123456'),
            'score'=>'98',
            'create_date'=>date('Y-m-d H:i:s'),
            'update_date'=>date('Y-m-d H:i:s'),
        ),
    );
  echo  M('User')->addAll($data); //实例化user表,并添加多条数据  通常用来记录日志
*/
//  echo M()->getLastSql(); //调试语句


//select 查询
//      $data=M('User')->select();
//        1.直接使用字符串进行查找
//        $data = M('User')->where('id=1')->select();

//        2.使用数组方法进行查询
//        $where['id']=2;
//        $where['user_name']='hello';
//        $where['_logic'] = 'or'; //将默认的and条件改为or
//        $data = M('User')->where($where)->select();

//        3.表达式查询(eq neq egt gt elt between in like)
//        $where['字段名'] = array(表达式,查询条件);
//        $where['id']=array('elt',3);
//        $where['id']=array('between','4,8'); //四到八之间
//        $where['id']=array('not in','2,4'); //不在这些数之中
//        $where['user_name']=array('like','%llo'); //模糊查询单个条件右匹配
//        $where['user_name']=array('like',array('%llo','h%')); //模糊查询多个条件查询左右同时匹配
//        $where['id']=array(array('gt',1),array('lt',10)); //多条件查询

//        4.区间查询
//        $where['id']=array(array('gt',100),array('lt',10),'or'); //默认and

//        5.混合查询
//        $where['_string']='score>98';

//        6.统计用法
        /*
         * count 统计用法 可选
         * max  获取最大值  必须传入统计的字段名
         * min  最小值     必须传入统计的字段名
         * avg  平均值     必须传入统计的字段名
         * sum  求和       必须传入统计的字段名
         * */
//       $data=M('User')->count();
//       $data=M('User')->max('id');
//        $data=M('User')->sum('score');


//        $data=M('User')->where($where)->select();
//        $where['id']=4;
//        $data = M('User')->where($where)->select();
//        dump($data);


//update 更新
//        $update['score']=60;
//        $where['id']=4;
//        $data=M('User')->where($where)->save($update);
//        $data = M('User')->where($where)->select();
//        dump($data);


//delete 删除
//        $where['id']=1;
//        $data=M('User')->where($where)->delete();
//        $data=M('User')->delete(2);  //传入主键直接删除

//        $data=M('User')->where()->select();
//        dump($data);


//连续操作
//        1.order 排序 order(字符串)多个条件用英文符号隔开
//        $data=M('User')->order('score desc,id asc')->select();
//        dump($data);

//        2.field($string,false) 传入多个字段名字用英文逗号隔开,过滤使用
//        $data=M('User')->field('id,user_name',true)->order('score desc,id asc')->select(); //默认false,传入true筛选所有的字段
//        dump($data);

//        3.limit(start,length) //限制查询的条数
//        $data=M('User')->field('id,user_name',true)->order('score desc,id asc')->limit(1,3)->select();
//        dump($data);

//        4.page(页码,每页显示的条数=20)
//        $data=M('User')->field('id,user_name')->order('id asc')->page(2)->select();
//        dump($data);

//        5.group分组操作
//        $data=M('User')->field('score,count(*)as total')->having('score>60')->group('score')->select();
//        dump($data);

//        6.多表查询 table方法 table(array('表名'=>'别名')) 表名需要加前缀
//        $data=M()->table(array('mk_user'=>'user','mk_userinfo'=>'info'))->where('user.id=info.user_id')->select();
//        dump($data);

//        7.多表查询join方法 支持字符串和数组
//        $data=M('User')->join('mk_userinfo On mk_userinfo.user_id=mk_user.id')->select(); //默认左关联
//        $data=M('User')->join('Right join mk_userinfo On mk_userinfo.user_id=mk_user.id')->select(); //从右边匹配左边
//        $data=M('User')->join('inner join mk_userinfo On mk_userinfo.user_id=mk_user.id')->select(); //同上
//        $data=M('User')->join(array('mk_userinfo On mk_userinfo.user_id=mk_user.id'))->select(); //数组查询默认左关联
//        dump($data);

//        8.多表查询 union查询 union('string或者array',true/false); 默认false
//        $data=M('User')->field('user_name')->union('select user_name from mk_user2')->select(); //只能查询两个表拥有的相同的字段并且类型一样
//        $data=M('User')->field('user_name')->union(array('field'=>'user_name','table'=>'mk_user2'),true)->select();
//        dump($data);

//        9.过滤查询 distinct
        $data=M('User')->distinct(true)->field('score')->order('score asc')->select();
        dump($data);


    $this->display(); //在debug中开启trace信息,此处调用,等效调用getLastSql()方法:显示数据库中最大id,在trace中查看sql信息
    }

}