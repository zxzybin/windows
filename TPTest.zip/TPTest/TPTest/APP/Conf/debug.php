<?php
/**
 * Created by PhpStorm.
 * User: Zhangleibin
 * Date: 2017/3/31
 * Time: 15:05
 */

return array(
    'name'=>'Donsen@debug',
    'SHOW_PAGE_TRACE'=>true, //显示页面trace信息(右下角点击图标查看效果)



);