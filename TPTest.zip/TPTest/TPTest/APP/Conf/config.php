<?php
return array(
	//'配置项'=>'配置值'
    'name'=>'Donsen',
    'LOAD_EXT_CONFIG'=>'user', //加载自定义配置文件,
    'URL_MODEL'=>2,
    'URL_HTML_SUFFIX'=>'shtml|html|xml', //url伪静态后缀设置

    //    'sex'=>'男',
    //  'URL_MODEL'=>0,



    //配置数据库(惰性连接)
    'DB_TYPE'=>'mysql', //数据库类型
    'DB_HOST'=>'localhost', //数据服务器地址
    'DB_NAME'=>'muke', //数据库名
    'DB_USER'=>'root', //用户名
    'DB_PWD'=>'', //密码
    'DB_PORT'=>'3306', //端口
    'DB_PREFIX'=>'mk_', //数据库表前缀

    //开启主从读写分离
    'DW_RW_SEPARATE'=>true,
    //多个主数据库服务器
    'DW_MASTER_NUM'=>'2',
);
?>