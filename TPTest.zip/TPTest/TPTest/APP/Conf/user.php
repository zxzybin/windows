<?php
/**
 * Created by PhpStorm.
 * User: Zhangleibin
 * Date: 2017/3/31
 * Time: 15:11
 */
return array(
    'sex'=>'boy',
);