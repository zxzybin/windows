<?php
/**
 * Created by PhpStorm.
 * User: Zhangleibin
 * Date: 2017/3/31
 * Time: 10:34
 */
function show(){
    echo '这是在common里自定义的show方法';
}