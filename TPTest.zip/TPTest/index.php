<?php
    define('APP_DEBUG',true); //打开调试模式
    define('APP_NAME','App');
    define('APP_PATH','./APP/');
    require('./ThinkPHP/ThinkPHP.php');